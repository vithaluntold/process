import DocumentUploadPage from "@/components/document-upload-page"

export default function Page() {
  return <DocumentUploadPage />
}
