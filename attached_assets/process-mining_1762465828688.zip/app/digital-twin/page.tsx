import DigitalTwinPage from "@/components/digital-twin-page"

export default function Page() {
  return <DigitalTwinPage />
}
