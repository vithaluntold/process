import ScenarioAnalysisPage from "@/components/scenario-analysis-page"

export default function Page() {
  return <ScenarioAnalysisPage />
}
