import ApiIntegrationPage from "@/components/api-integration-page"

export default function Page() {
  return <ApiIntegrationPage />
}
